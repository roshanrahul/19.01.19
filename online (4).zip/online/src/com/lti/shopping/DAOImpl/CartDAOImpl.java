package com.lti.shopping.DAOImpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.shopping.DAO.CartDAO;
import com.lti.shopping.model.Cart;
import com.lti.shopping.model.Product;


@Repository("CartDAO")
public class CartDAOImpl implements CartDAO{
	private static final Logger logger = 			
			LoggerFactory.getLogger(CartDAOImpl.class);
	
 
	Transaction tx;
	@Autowired
	private SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
			  
	
	

	@Override
	public Cart get(Integer id) {
		System.out.println("get");
		System.out.println(id);
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();

		System.out.println("get1");
		Cart c = (Cart) session.get(Product.class, id);
		System.out.println("get2");
		logger.info("Product loaded successfully, Product details=" + c);
		return c;
	

	}

	
	

	
	@Override
	public void add(Cart cart) {
		Session session = this.sessionFactory.openSession();
		tx =  session.beginTransaction();
		session.save(cart);
		tx.commit();
		session.close();
		logger.info("Product details saved successfully, User Details="+cart);

	}
	@Override
	public List<Cart> listCart() {
		Session session = this.sessionFactory.openSession();
		tx =  session.beginTransaction();
		System.out.println("helloi");
		List<Cart> cartList = session.createQuery("from Cart").list();
		System.out.println("helloii");
		for (Cart c : cartList) {
			logger.info("Product List::" + c);
		}
		System.out.println("helloiiiii");
		session.close();
		return cartList;

	}

}
