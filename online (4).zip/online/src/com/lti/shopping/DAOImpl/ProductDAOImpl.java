package com.lti.shopping.DAOImpl;

import java.util.List;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.shopping.DAO.ProductDAO;
import com.lti.shopping.model.Product;



@Repository("ProductDAO")
public class ProductDAOImpl implements ProductDAO {
	
	private static final Logger logger = 			
			LoggerFactory.getLogger(ProductDAOImpl.class);
	
 
	Transaction tx;
	@Autowired
	private SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
			  
	
	

	@Override
	public Product get(Integer product_id) {
		System.out.println("get");
		System.out.println(product_id);
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();

		System.out.println("get1");
		Product p = (Product) session.get(Product.class, product_id);
		System.out.println("get2");
		logger.info("Product loaded successfully, Product details=" + p);
		return p;
	

	}

	
	

	
	@Override
	public void add(Product product) {
		Session session = this.sessionFactory.openSession();
		tx =  session.beginTransaction();
		session.save(product);
		tx.commit();
		session.close();
		logger.info("Product details saved successfully, User Details="+product);

	}

	@Override
	public void updProduct(Product product) {
		 
		Session session = this.sessionFactory.openSession();
		tx =  session.beginTransaction();
		System.out.println("in updatedao");
		session.saveOrUpdate(product);
		System.out.println("after updatedao");
		logger.info("Person updated successfully,Person Details=" + product);
		tx.commit();
		

		session.close();
	}

	@Override
	public void delProduct(int product_id) {
		
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Product product = (Product) session.get(Product.class, product_id);
			session.delete(product);
			System.out.println("Product deleted successfully");
			tx.commit();
		
			session.close();

	}





	@Override
	public List<Product> listProducts() {
		Session session = this.sessionFactory.openSession();
		tx =  session.beginTransaction();
		System.out.println("helloi");
		List<Product> productList = session.createQuery("from Product").list();
		System.out.println("helloii");
		for (Product p : productList) {
			logger.info("Product List::" + p);
		}
		System.out.println("helloiiiii");
		session.close();
		return productList;

	}


		 
	}


