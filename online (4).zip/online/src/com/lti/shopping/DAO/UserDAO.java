package com.lti.shopping.DAO;



import org.springframework.stereotype.Repository;

import com.lti.shopping.model.UserDetails;


@Repository
public interface UserDAO {

	// user related operation
//	String getByEmail(String email);
	UserDetails get(int id);
 
	void addUser(UserDetails u);
	boolean verifyUser(String email, String password);
	
	// adding and updating a new address
	//Address getAddress(int addressId);
//	boolean addAddress(Address address);
//	boolean updateAddress(Address address);
//	Address getBillingAddress(int userId);
//	List<Address> listShippingAddresses(int userId);
	

	
}