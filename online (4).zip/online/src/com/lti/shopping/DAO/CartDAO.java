package com.lti.shopping.DAO;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.shopping.model.Cart;

@Repository
public interface CartDAO {
	public Cart get(Integer id);
	public List<Cart> listCart();
	void add(Cart cart);
}

