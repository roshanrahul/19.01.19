package com.lti.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.shopping.DAO.CartDAO;

import com.lti.shopping.model.Cart;


@Service
@Transactional
public class CartServiceImpl implements cartService{
	 @Autowired
		private CartDAO cartDAO;
		


		public void setCartDAO(CartDAO cartDAO) {
			this.cartDAO = cartDAO;
		}

	     @Override
		public Cart get(Integer id) {
			 
			return cartDAO.get(id);
		}

		

		@Override
		public void add(Cart cart) {
			System.out.println("in service");
			this.cartDAO.add(cart);
			
		}
		@Override
		@Transactional
		public List<Cart> listCart() {
			return cartDAO.listCart();
		}
}
