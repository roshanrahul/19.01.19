package com.lti.shopping.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.shopping.model.Cart;

@Service
public interface cartService {
	public Cart get(Integer id);
	public List<Cart> listCart();
	void add(Cart cart);
}
