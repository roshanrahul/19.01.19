
package com.lti.shopping.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity

@Table(name = "Seller")
public class Seller implements Serializable {

	private static final long serialVersionUID = 1L;

	@OneToMany(cascade = CascadeType.ALL,mappedBy="seller")
private List<Product> plist;

//	  @ManyToMany(cascade=CascadeType.ALL)
//	  
//	  @JoinTable(name="Seller_product", joinColumns=
//	  {@JoinColumn(name="sellId",referencedColumnName="sellId")},
//	  inverseJoinColumns=
//	  {@JoinColumn(name="product_id",referencedColumnName="product_id")})
	// ArrayList<Product> list ;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer sellId;

	private String firstName;

	private String lastName;

	private String email;

	private String address;

	private String password;

	private String confirmPassword;

	@Column(name = "contactno")
	private int contactNumber;

	
	/*
	 * public Product getProduct() { return product; }
	 * 
	 * public void setProduct(Product product) { this.product = product; }
	 */
	 

	public Integer getSellId() {
		return sellId;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	// public List<Product> getList() { return list; }

	// public void setList(ArrayList<Product> list) { this.list = list; }

	public void setSellId(Integer sellId) {
		this.sellId = sellId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(int contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Seller() {
		super();
	}

	public List<Product> getPlist() {
		return plist;
	}

	public void setPlist(List<Product> plist) {
		this.plist = plist;
	}

	
	

}
